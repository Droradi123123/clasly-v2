import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { useIsMobile } from "@/hooks/useIsMobile";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { supabase } from "@/integrations/supabase/client";
import { getOAuthAllowedHosts } from "@/lib/authUtils";
import { toast } from "sonner";
import { Sparkles, Mail, ArrowRight, Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useEffect, useRef } from "react";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  promptText?: string;
  redirectTo?: 'dashboard' | 'builder';
}

export const AuthModal = ({ isOpen, onClose, onSuccess, promptText, redirectTo = 'dashboard' }: AuthModalProps) => {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const [isLoading, setIsLoading] = useState(false);
  const [showEmailForm, setShowEmailForm] = useState(false);
  const [isSignUp, setIsSignUp] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const hasHandledAuth = useRef(false);
  
  // Listen for auth state changes to handle post-login navigation
  useEffect(() => {
    if (!isOpen) {
      hasHandledAuth.current = false;
      return;
    }
    
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      // Handle successful sign in (both email and OAuth)
      if (event === 'SIGNED_IN' && session && !hasHandledAuth.current) {
        hasHandledAuth.current = true;
        
        // Close modal and navigate
        onClose();
        
        // Always save prompt before redirect so user never loses it (mobile: for when they continue on desktop)
        if (promptText && redirectTo === 'builder') {
          localStorage.setItem('clasly_pending_prompt', promptText);
        }
        
        // Mobile: go to Continue on Desktop (prompt saved for when they open on desktop)
        if (isMobile) {
          navigate('/continue-on-desktop', { replace: true });
        } else if (promptText && redirectTo === 'builder') {
          navigate(`/builder?prompt=${encodeURIComponent(promptText)}&audience=general`);
        } else {
          navigate('/dashboard');
        }
        
        onSuccess?.();
      }
    });
    
    return () => {
      subscription.unsubscribe();
    };
  }, [isOpen, onClose, onSuccess, promptText, redirectTo, navigate, isMobile]);
  
  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    try {
      // Store prompt for after redirect (only if going to builder)
      if (promptText && redirectTo === 'builder') {
        localStorage.setItem("clasly_pending_prompt", promptText);
      }

      if (isMobile) {
        sessionStorage.setItem("clasly_mobile_oauth_pending", "1");
      }
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: {
          redirectTo: window.location.origin,
          skipBrowserRedirect: true,
        },
      });

      if (error) {
        toast.error("Failed to sign in with Google");
        console.error("Google sign-in error:", error);
        setIsLoading(false);
        return;
      }

      if (data?.url) {
        const oauthUrl = new URL(data.url);
        const allowedHosts = getOAuthAllowedHosts();
        if (!allowedHosts.some((host) => oauthUrl.hostname === host || oauthUrl.hostname.endsWith("." + host))) {
          throw new Error("Invalid OAuth redirect URL");
        }
        window.location.href = data.url;
      }
    } catch (err) {
      toast.error("An unexpected error occurred");
      console.error(err);
      setIsLoading(false);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      if (isSignUp) {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: getRedirectUrl(),
          },
        });
        
        if (error) {
          if (error.message.includes("already registered")) {
            toast.error("This email is already registered. Please sign in instead.");
            setIsSignUp(false);
          } else {
            toast.error(error.message);
          }
          setIsLoading(false);
        } else {
          toast.success("Check your email for a confirmation link!");
          setIsLoading(false);
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        
        if (error) {
          toast.error(error.message);
          setIsLoading(false);
        }
        // On success, the onAuthStateChange listener will handle navigation
      }
    } catch (err) {
      toast.error("An unexpected error occurred");
      console.error(err);
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-[calc(100vw-2rem)] sm:max-w-md w-[calc(100vw-2rem)] sm:w-full p-0 overflow-hidden border-border/50 bg-background max-h-[90vh] overflow-y-auto">
        {/* Decorative header - compact on mobile */}
        <div className="relative bg-gradient-to-br from-primary/10 via-primary/5 to-transparent px-4 sm:px-6 pt-5 sm:pt-8 pb-4 sm:pb-6">
          <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-primary/10 rounded-full blur-2xl" />
          
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="relative"
          >
            <div className={`rounded-2xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center shadow-lg shadow-primary/20 ${isMobile ? "w-11 h-11 mb-3" : "w-14 h-14 mb-4"}`}>
              <Sparkles className={`text-primary-foreground ${isMobile ? "w-6 h-6" : "w-7 h-7"}`} />
            </div>
            <DialogTitle className={`font-display font-bold text-foreground mb-2 ${isMobile ? "text-xl" : "text-2xl"}`}>
              {promptText ? "Let's build your presentation!" : "Welcome to Clasly"}
            </DialogTitle>
            <p className="text-muted-foreground text-sm">
              {promptText 
                ? "Sign in to start creating your AI-powered presentation" 
                : "Sign in to create interactive presentations in seconds"
              }
            </p>
          </motion.div>
        </div>

        <div className="px-4 sm:px-6 pb-4 sm:pb-6">
          <AnimatePresence mode="wait">
            {!showEmailForm ? (
              <motion.div
                key="main"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-4"
              >
                {/* Google Sign In - Primary */}
                <Button
                  variant="outline"
                  size="lg"
                  onClick={handleGoogleSignIn}
                  disabled={isLoading}
                  className="w-full h-11 sm:h-12 text-sm sm:text-base font-medium border-2 hover:border-primary/50 hover:bg-primary/5 transition-all"
                >
                  {isLoading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
                        <path
                          fill="#4285F4"
                          d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                        />
                        <path
                          fill="#34A853"
                          d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                        />
                        <path
                          fill="#FBBC05"
                          d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                        />
                        <path
                          fill="#EA4335"
                          d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                        />
                      </svg>
                      Continue with Google
                    </>
                  )}
                </Button>

                <div className="relative">
                  <Separator className="my-4" />
                  <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-background px-3 text-xs text-muted-foreground">
                    or
                  </span>
                </div>

                {/* Email option */}
                <Button
                  variant="ghost"
                  size="lg"
                  onClick={() => setShowEmailForm(true)}
                  className="w-full h-11 text-sm text-muted-foreground hover:text-foreground"
                >
                  <Mail className="w-4 h-4 mr-2" />
                  Continue with email
                  <ArrowRight className="w-4 h-4 ml-auto" />
                </Button>
              </motion.div>
            ) : (
              <motion.form
                key="email"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                onSubmit={handleEmailAuth}
                className="space-y-4"
              >
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="h-11"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    minLength={6}
                    className="h-11"
                  />
                </div>

                <Button
                  type="submit"
                  size="lg"
                  disabled={isLoading}
                  className="w-full h-11"
                >
                  {isLoading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    isSignUp ? "Create Account" : "Sign In"
                  )}
                </Button>

                <div className="flex items-center justify-between text-sm">
                  <button
                    type="button"
                    onClick={() => setShowEmailForm(false)}
                    className="text-muted-foreground hover:text-foreground transition-colors"
                  >
                    ← Back
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsSignUp(!isSignUp)}
                    className="text-primary hover:underline"
                  >
                    {isSignUp ? "Already have an account?" : "Create new account"}
                  </button>
                </div>
              </motion.form>
            )}
          </AnimatePresence>

          {/* Trust indicators */}
          <div className="mt-4 sm:mt-6 pt-3 sm:pt-4 border-t border-border/50">
            <p className="text-xs text-center text-muted-foreground">
              By continuing, you agree to our{" "}
              <a href="/terms" className="text-primary hover:underline" target="_blank" rel="noopener noreferrer">Terms of Service</a>
              {" "}and{" "}
              <a href="/privacy" className="text-primary hover:underline" target="_blank" rel="noopener noreferrer">Privacy Policy</a>
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AuthModal;
